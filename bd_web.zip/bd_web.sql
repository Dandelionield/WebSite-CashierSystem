-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2024 at 08:05 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bd_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `download`
--

CREATE TABLE `download` (
  `ID` text NOT NULL,
  `date` date NOT NULL,
  `description` text NOT NULL,
  `Link` text NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `download`
--

INSERT INTO `download` (`ID`, `date`, `description`, `Link`, `img`) VALUES
('1.4.8', '2014-05-14', 'Versión no comercial sin completar xd', 'https://github.com/Dandelionield/CashierSystem', 'http://localhost/WebSite-CashierSystem/styles/imagenes/downloads/s6.PNG'),
('1.4.9', '2019-05-19', 'Prueba#1', 'https://github.com/Dandelionield/CashierSystem', 'http://localhost/WebSite-CashierSystem/styles/imagenes/downloads/Formula1.PNG'),
('1.5.0', '2019-05-19', 'Prueba#2', 'https://github.com/Dandelionield/CashierSystem', 'http://localhost/WebSite-CashierSystem/styles/imagenes/downloads/bruh.jpg'),
('1.5.1', '2019-05-19', 'Prueba#3', 'https://github.com/Dandelionield/CashierSystem', 'http://localhost/WebSite-CashierSystem/styles/imagenes/downloads/imagen_2024-05-19_130406839.png');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id_user` int(11) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id_user`, `message`) VALUES
(4, 'hola'),
(4, 'asd'),
(6, 'test test test test'),
(5, 'gghfhjk'),
(6, 'asdfd'),
(4, 'esto es una prueba asd');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `admin` bit(1) NOT NULL DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nickname`, `email`, `password`, `admin`) VALUES
(4, 'Cleiver', 'cleivermr@gmail.com', 'cleiver12345', b'0'),
(5, 'Leo', 'leo@gmail.com', '1234567890', b'0'),
(6, 'test', 'test@gmail.com', 'asdasdlasdka', b'0'),
(7, 'asda', 'dsadsd', 'dsad', b'0'),
(8, 'dsa', 'dsfsdf', 'sddfsdf', b'0'),
(9, 'juan', 'asdasda', 'asdasd', b'1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `download`
--
ALTER TABLE `download`
  ADD PRIMARY KEY (`ID`(5));

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
